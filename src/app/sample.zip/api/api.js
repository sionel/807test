const $app = document.getElementById("app");
const $test = document.createElement("a");
$test.innerText = "api 테스트";
$app.append($test);
