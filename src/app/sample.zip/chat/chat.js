const $app = document.getElementById("app");
const $test = document.createElement("a");
$test.innerText = "채팅 테스트";
$app.append($test);
