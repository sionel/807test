const $app = document.getElementById("app");
const $test = document.createElement("a");
$test.innerText = "계산기 테스트";
$app.append($test);
